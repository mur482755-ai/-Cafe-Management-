package com.mycompany.cafemanagement;

/**
 *
 * @author UC 313
 */
public class CafeManagement {
    public static void main(String[] args) {
        new Coverpg().setVisible(true);
        System.out.println("App is running!");
    }
}