package com.mycompany.cafemanagement;


import java.awt.Image;
import java.awt.Toolkit;
import java.awt.print.PrinterException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author UC 313
 */
public class Loginpage extends javax.swing.JFrame {
  private double total=0.0;
  private final String imagesFolder = "images";
 
    /**
     * Creates new form Loginpage
     */
    public Loginpage() {
        initComponents();
        init();
        SetApplicationIcon();
    }
private int x = 0; 
private double tax=0.0;// Counter for item numbering
  public void init() {
    setImage();
    setTime();
}
  
 public String getImagePath(String fileName)
{
    return imagesFolder+"/"+fileName;
}
 
public void SetApplicationIcon()
{
     // Set application icon
        setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource(getImagePath("coffee.jpg"))));
}

public void setImage() {
    
    
//    try {
//    ImageIcon coldCoffeeIcon  = new ImageIcon(getClass().getResource(getImagePath("coffee.jpg")));
//    java.net.URL imageURL = getClass().getResource("Images/coffee.jpg");
//    if (imageURL == null) {
//        System.err.println("Image not found!");
//        return;
//    }
//   
//    System.out.println("Original image size: " + coldCoffeeIcon.getIconWidth() + "x" + coldCoffeeIcon.getIconHeight());
//    System.out.println("Label size: " + labelColdCoffee.getWidth() + "x" + labelColdCoffee.getHeight());
//    
//    Image coldCoffeeImage = coldCoffeeIcon.getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH);
//    labelColdCoffee.setIcon(new ImageIcon(coldCoffeeImage));
//} catch (Exception e) {
//    e.printStackTrace();
//}

    // Load images from resource folder
    ImageIcon coldCoffeeIcon  = new ImageIcon(getClass().getResource(getImagePath("coffee.jpg")));
    ImageIcon icon1 = new ImageIcon(getClass().getResource(getImagePath("tea.jpeg")));
    ImageIcon icon2 = new ImageIcon(getClass().getResource(getImagePath("smoothies.jpeg")));
    ImageIcon icon3 = new ImageIcon(getClass().getResource(getImagePath("cupcakes.jpeg")));
    ImageIcon icon4 = new ImageIcon(getClass().getResource(getImagePath("fruitcakes.jpeg")));
    ImageIcon icon5 = new ImageIcon(getClass().getResource(getImagePath("brownies.jpg")));
    ImageIcon icon6 = new ImageIcon(getClass().getResource(getImagePath("cookies.jpeg")));
    ImageIcon icon7 = new ImageIcon(getClass().getResource(getImagePath("sandwiches.jpg")));
    
    

    // Scale images to match label sizes
    Image coldCoffeeImage  = coldCoffeeIcon.getImage().getScaledInstance(labelColdCoffee.getWidth(), labelColdCoffee.getHeight(), Image.SCALE_SMOOTH);
    Image img1 = icon1.getImage().getScaledInstance(jLabelimage1.getWidth(), jLabelimage1.getHeight(), Image.SCALE_SMOOTH);
    Image img2 = icon2.getImage().getScaledInstance(jLabelimage.getWidth(), jLabelimage.getHeight(), Image.SCALE_SMOOTH);
    Image img3 = icon3.getImage().getScaledInstance(jLabel39.getWidth(), jLabel39.getHeight(), Image.SCALE_SMOOTH);
    Image img4 = icon4.getImage().getScaledInstance(jLabel59.getWidth(), jLabel59.getHeight(), Image.SCALE_SMOOTH);
    Image img5 = icon5.getImage().getScaledInstance(jLabel66.getWidth(), jLabel66.getHeight(), Image.SCALE_SMOOTH);
    Image img6 = icon6.getImage().getScaledInstance(jLabel73.getWidth(), jLabel73.getHeight(), Image.SCALE_SMOOTH);
    Image img7 = icon7.getImage().getScaledInstance(jLabel80.getWidth(), jLabel80.getHeight(), Image.SCALE_SMOOTH);

    // Set images to JLabels
    labelColdCoffee.setIcon(new ImageIcon(coldCoffeeImage));
    jLabelimage1.setIcon(new ImageIcon(img1));
    jLabelimage.setIcon(new ImageIcon(img2));
    jLabel39.setIcon(new ImageIcon(img3));
    jLabel59.setIcon(new ImageIcon(img4));
    jLabel66.setIcon(new ImageIcon(img5));
    jLabel73.setIcon(new ImageIcon(img6));
    jLabel80.setIcon(new ImageIcon(img7));
}
    public boolean qtyIsZero(int qty){
        if(Integer.parseInt(jSpinner4.getValue().toString())==0){
        JOptionPane.showMessageDialog(null, "Please select quantity first!");
        return true;
        }
        return true;
    } 

    public void reset() {
        total=0.0;
        x=0;
        tax=0.0;
        btnTotal.setEnabled(true);
    jSpinner4.setValue(0);
    jSpinner5.setValue(0);
    jSpinner2.setValue(0);
    jSpinner3.setValue(0);
    jSpinner6.setValue(0);
    jSpinner7.setValue(0);
    jSpinner8.setValue(0);
    jSpinner9.setValue(0);

    jTextFieldTax.setText("0.0");
    jTextFieldSubTotal.setText("0.0");
    jTextFieldTotal.setText("0.0");

    jCheckBox4.setSelected(false);
    jCheckBox5.setSelected(false);
    jCheckBox2.setSelected(false);
    jCheckBox3.setSelected(false);
    jCheckBox6.setSelected(false);
    jCheckBox7.setSelected(false);
    jCheckBox8.setSelected(false);
    jCheckBox9.setSelected(false);
    // Clear result display (example if you use a JTextArea or JLabel)
    jTextArea.setText(""); // or any component that shows previous results
}
    public void dudate(){
    jTextFieldTax.setText(String.valueOf(String.format("%.2f",tax)));
    jTextFieldSubTotal.setText(String.valueOf(String.format("%.2f",total)));
    jTextFieldTotal.setText(String.valueOf(String.format("%.2f",total+tax)));
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jCheckBox1 = new javax.swing.JCheckBox();
        jTextField1 = new javax.swing.JTextField();
        jPasswordField1 = new javax.swing.JPasswordField();
        jButton7 = new javax.swing.JButton();
        jSpinner1 = new javax.swing.JSpinner();
        jPanel1 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jPanel12 = new javax.swing.JPanel();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jPanel21 = new javax.swing.JPanel();
        jButton10 = new javax.swing.JButton();
        jPanel22 = new javax.swing.JPanel();
        jButton11 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        jButton13 = new javax.swing.JButton();
        jButton14 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jLabel47 = new javax.swing.JLabel();
        jLabel53 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jLabel81 = new javax.swing.JLabel();
        jLabel74 = new javax.swing.JLabel();
        jLabel67 = new javax.swing.JLabel();
        jLabel60 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jButton18 = new javax.swing.JButton();
        jLabel46 = new javax.swing.JLabel();
        jSpinner10 = new javax.swing.JSpinner();
        jLabel93 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        jLabelimage = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jSpinner2 = new javax.swing.JSpinner();
        jCheckBox2 = new javax.swing.JCheckBox();
        jPanel14 = new javax.swing.JPanel();
        jLabel39 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        jSpinner3 = new javax.swing.JSpinner();
        jCheckBox3 = new javax.swing.JCheckBox();
        jPanel15 = new javax.swing.JPanel();
        jLabel48 = new javax.swing.JLabel();
        jLabel49 = new javax.swing.JLabel();
        jLabel50 = new javax.swing.JLabel();
        jLabel51 = new javax.swing.JLabel();
        jLabel52 = new javax.swing.JLabel();
        jSpinner4 = new javax.swing.JSpinner();
        jCheckBox4 = new javax.swing.JCheckBox();
        labelColdCoffee = new javax.swing.JLabel();
        jPanel16 = new javax.swing.JPanel();
        jLabelimage1 = new javax.swing.JLabel();
        jLabel54 = new javax.swing.JLabel();
        jLabel55 = new javax.swing.JLabel();
        jLabel56 = new javax.swing.JLabel();
        jLabel57 = new javax.swing.JLabel();
        jLabel58 = new javax.swing.JLabel();
        jSpinner5 = new javax.swing.JSpinner();
        jCheckBox5 = new javax.swing.JCheckBox();
        jPanel17 = new javax.swing.JPanel();
        jLabel59 = new javax.swing.JLabel();
        jLabel61 = new javax.swing.JLabel();
        jLabel62 = new javax.swing.JLabel();
        jLabel63 = new javax.swing.JLabel();
        jLabel64 = new javax.swing.JLabel();
        jLabel65 = new javax.swing.JLabel();
        jSpinner6 = new javax.swing.JSpinner();
        jCheckBox6 = new javax.swing.JCheckBox();
        jPanel18 = new javax.swing.JPanel();
        jLabel66 = new javax.swing.JLabel();
        jLabel68 = new javax.swing.JLabel();
        jLabel69 = new javax.swing.JLabel();
        jLabel70 = new javax.swing.JLabel();
        jLabel71 = new javax.swing.JLabel();
        jLabel72 = new javax.swing.JLabel();
        jSpinner7 = new javax.swing.JSpinner();
        jCheckBox7 = new javax.swing.JCheckBox();
        jPanel19 = new javax.swing.JPanel();
        jLabel73 = new javax.swing.JLabel();
        jLabel75 = new javax.swing.JLabel();
        jLabel76 = new javax.swing.JLabel();
        jLabel77 = new javax.swing.JLabel();
        jLabel78 = new javax.swing.JLabel();
        jLabel79 = new javax.swing.JLabel();
        jSpinner8 = new javax.swing.JSpinner();
        jCheckBox8 = new javax.swing.JCheckBox();
        jPanel20 = new javax.swing.JPanel();
        jLabel80 = new javax.swing.JLabel();
        jLabel82 = new javax.swing.JLabel();
        jLabel83 = new javax.swing.JLabel();
        jLabel84 = new javax.swing.JLabel();
        jLabel85 = new javax.swing.JLabel();
        jLabel86 = new javax.swing.JLabel();
        jSpinner9 = new javax.swing.JSpinner();
        jCheckBox9 = new javax.swing.JCheckBox();
        jLabel32 = new javax.swing.JLabel();
        btnTotal = new javax.swing.JButton();
        btnReceipt = new javax.swing.JButton();
        btnReset = new javax.swing.JButton();
        btnExit = new javax.swing.JButton();
        jPanel23 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea = new javax.swing.JTextArea();
        jTextFieldTotal = new javax.swing.JTextField();
        jTextFieldTax = new javax.swing.JTextField();
        jTextFieldSubTotal = new javax.swing.JTextField();
        jLabel87 = new javax.swing.JLabel();
        jLabel88 = new javax.swing.JLabel();
        jPanel24 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTextArea3 = new javax.swing.JTextArea();
        jTextField5 = new javax.swing.JTextField();
        jTextField6 = new javax.swing.JTextField();
        jTextField7 = new javax.swing.JTextField();
        jLabel89 = new javax.swing.JLabel();
        jLabel90 = new javax.swing.JLabel();
        jLabel91 = new javax.swing.JLabel();
        jTxTime = new javax.swing.JLabel();
        jTxtDate = new javax.swing.JLabel();
        jLabel94 = new javax.swing.JLabel();

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("EMAIL");

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("PASSWORD");

        jCheckBox1.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        jCheckBox1.setText("Remember me");
        jCheckBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox1ActionPerformed(evt);
            }
        });

        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });

        jPasswordField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jPasswordField1ActionPerformed(evt);
            }
        });

        jButton7.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton7.setText("PASTRIES");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jLabel6.setText("MENU");

        jLabel7.setBackground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("jLabel7");

        jLabel10.setText("jLabel10");

        jLabel11.setText("jLabel11");

        jLabel12.setText("jLabel12");

        jLabel13.setText("jLabel13");
        jLabel13.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);

        jLabel14.setText("jLabel14");

        jPanel10.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(230, 230, 230), 2, true));

        jLabel15.setText("jLabel15");

        jLabel16.setText("jLabel16");

        jLabel17.setText("jLabel17");

        jLabel18.setText("jLabel18");

        jPanel11.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230), 2));

        jLabel19.setText("jLabel19");

        jLabel23.setText("jLabel23");

        jLabel22.setText("jLabel22");

        jLabel21.setText("jLabel21");

        jLabel20.setText("jLabel20");

        jLabel9.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel9.setText("                                                         MENU ITEMS");

        jLabel26.setText("jLabel26");

        jLabel25.setText("Name");
        jLabel25.setToolTipText("");

        jLabel27.setText("jLabel27");

        jLabel28.setText("NAME");

        jPanel12.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230), 2));
        jPanel12.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel30.setText("jLabel30");
        jPanel12.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, -1, -1));

        jLabel31.setText("jLabel31");

        jButton2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton2.setText("PLACE ORDER");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton9.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton9.setText("COOKIES");

        jButton4.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton4.setText("CAKE");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton5.setText("SANDWICHES");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton6.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton6.setText("SMOOTHIES");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton3.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton3.setText("COFFEE");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton8.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton8.setText("BROWNIES");

        jButton1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton1.setText("TEA");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton10.setText("jButton10");

        jPanel22.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230), 2));
        jPanel22.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton11.setBackground(new java.awt.Color(204, 204, 255));
        jButton11.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton11.setText("Total");
        jPanel22.add(jButton11, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 100, 40));

        jButton12.setBackground(new java.awt.Color(255, 204, 204));
        jButton12.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton12.setText("Receipt");
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });
        jPanel22.add(jButton12, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 20, 100, 40));

        jButton13.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton13.setText("Reset");
        jPanel22.add(jButton13, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 20, 90, 40));

        jButton14.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton14.setText("Exit");
        jPanel22.add(jButton14, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 20, 90, 40));

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        jLabel47.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel47.setText("Name");

        jLabel53.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel53.setText("Name");

        jLabel33.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel33.setText("Name");

        jLabel81.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel81.setText("Name");

        jLabel74.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel74.setText("Name");

        jLabel67.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel67.setText("Name");

        jLabel60.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel60.setText("Name");

        jLabel40.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel40.setText("Name");

        jButton18.setText("jButton18");

        jLabel93.setIcon(new javax.swing.ImageIcon("C:\\Users\\UC 313\\OneDrive\\Documents\\NetBeansProjects\\CafeManagement\\src\\main\\java\\Images\\88.jpg")); // NOI18N
        jLabel93.setText("jLabel93");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                formMouseDragged(evt);
            }
        });
        addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                formMousePressed(evt);
            }
        });
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel1.setText("MY CAFE");
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jLabel1MousePressed(evt);
            }
        });
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, -1, -1));
        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 30));

        jPanel3.setBackground(new java.awt.Color(204, 204, 204));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230), 2));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel13.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230), 2));
        jPanel13.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel13.add(jLabelimage, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 160, 50));

        jLabel34.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel34.setText("Price");
        jPanel13.add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, -1, -1));

        jLabel35.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel35.setText("Quantity");
        jPanel13.add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, -1, -1));

        jLabel36.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel36.setText("Purchase");
        jPanel13.add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, -1, -1));

        jLabel37.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel37.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel37.setText("Smoothies");
        jPanel13.add(jLabel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(9, 60, 130, -1));

        jLabel38.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel38.setText("$60.0");
        jPanel13.add(jLabel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 80, -1, -1));

        jSpinner2.setModel(new javax.swing.SpinnerNumberModel(0, 0, 50, 1));
        jPanel13.add(jSpinner2, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 100, 50, 20));

        jCheckBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox2ActionPerformed(evt);
            }
        });
        jPanel13.add(jCheckBox2, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 120, 50, 20));

        jPanel3.add(jPanel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 80, 160, 150));

        jPanel14.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230), 2));
        jPanel14.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel14.add(jLabel39, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 160, 50));

        jLabel41.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel41.setText("Price");
        jPanel14.add(jLabel41, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, -1, -1));

        jLabel42.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel42.setText("Quantity");
        jPanel14.add(jLabel42, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, -1, -1));

        jLabel43.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel43.setText("Purchase");
        jPanel14.add(jLabel43, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, -1, -1));

        jLabel44.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel44.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel44.setText("Cupcakes");
        jPanel14.add(jLabel44, new org.netbeans.lib.awtextra.AbsoluteConstraints(15, 60, 130, -1));

        jLabel45.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel45.setText("$55.0");
        jPanel14.add(jLabel45, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 80, -1, -1));

        jSpinner3.setModel(new javax.swing.SpinnerNumberModel(0, 0, 50, 1));
        jPanel14.add(jSpinner3, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 100, 50, 20));

        jCheckBox3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox3ActionPerformed(evt);
            }
        });
        jPanel14.add(jCheckBox3, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 120, 50, 20));

        jPanel3.add(jPanel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 80, 160, 150));

        jPanel15.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230), 2));
        jPanel15.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel48.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel48.setText("Price");
        jPanel15.add(jLabel48, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, -1, -1));

        jLabel49.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel49.setText("Quantity");
        jPanel15.add(jLabel49, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, -1, -1));

        jLabel50.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel50.setText("Purchase");
        jPanel15.add(jLabel50, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, -1, -1));

        jLabel51.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel51.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel51.setText("Cold Coffee");
        jPanel15.add(jLabel51, new org.netbeans.lib.awtextra.AbsoluteConstraints(8, 60, 140, -1));

        jLabel52.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel52.setText("$80.0");
        jPanel15.add(jLabel52, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 80, -1, -1));

        jSpinner4.setModel(new javax.swing.SpinnerNumberModel(0, 0, 50, 1));
        jPanel15.add(jSpinner4, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 100, 50, 20));

        jCheckBox4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox4ActionPerformed(evt);
            }
        });
        jPanel15.add(jCheckBox4, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 120, 50, 20));
        jPanel15.add(labelColdCoffee, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 160, 50));

        jPanel3.add(jPanel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, 160, 150));

        jPanel16.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230), 2));
        jPanel16.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel16.add(jLabelimage1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 160, 50));

        jLabel54.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel54.setText("Price");
        jPanel16.add(jLabel54, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, -1, -1));

        jLabel55.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel55.setText("Quantity");
        jPanel16.add(jLabel55, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, -1, -1));

        jLabel56.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel56.setText("Purchase");
        jPanel16.add(jLabel56, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, -1, -1));

        jLabel57.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel57.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel57.setText(" Tea");
        jPanel16.add(jLabel57, new org.netbeans.lib.awtextra.AbsoluteConstraints(15, 60, 140, -1));

        jLabel58.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel58.setText("$45.0");
        jPanel16.add(jLabel58, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 80, -1, -1));

        jSpinner5.setModel(new javax.swing.SpinnerNumberModel(0, 0, 50, 1));
        jPanel16.add(jSpinner5, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 100, 50, 20));

        jCheckBox5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox5ActionPerformed(evt);
            }
        });
        jPanel16.add(jCheckBox5, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 120, 50, 20));

        jPanel3.add(jPanel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 80, -1, 150));

        jPanel17.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230), 2));
        jPanel17.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel17.add(jLabel59, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 160, 50));

        jLabel61.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel61.setText("Price");
        jPanel17.add(jLabel61, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, -1, -1));

        jLabel62.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel62.setText("Quantity");
        jPanel17.add(jLabel62, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, -1, -1));

        jLabel63.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel63.setText("Purchase");
        jPanel17.add(jLabel63, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, -1, -1));

        jLabel64.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel64.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel64.setText("Fruit Cakes");
        jPanel17.add(jLabel64, new org.netbeans.lib.awtextra.AbsoluteConstraints(5, 60, 150, -1));

        jLabel65.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel65.setText("$50.0");
        jPanel17.add(jLabel65, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 80, -1, -1));

        jSpinner6.setModel(new javax.swing.SpinnerNumberModel(0, 0, 50, 1));
        jPanel17.add(jSpinner6, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 100, 50, 20));

        jCheckBox6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox6ActionPerformed(evt);
            }
        });
        jPanel17.add(jCheckBox6, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 120, 50, 20));

        jPanel3.add(jPanel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 250, -1, 150));

        jPanel18.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230), 2));
        jPanel18.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel18.add(jLabel66, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 160, 50));

        jLabel68.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel68.setText("Price");
        jPanel18.add(jLabel68, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, -1, -1));

        jLabel69.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel69.setText("Quantity");
        jPanel18.add(jLabel69, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, -1, -1));

        jLabel70.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel70.setText("Purchase");
        jPanel18.add(jLabel70, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, -1, -1));

        jLabel71.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel71.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel71.setText("Brownies");
        jPanel18.add(jLabel71, new org.netbeans.lib.awtextra.AbsoluteConstraints(3, 60, 150, -1));

        jLabel72.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel72.setText("$70.0");
        jPanel18.add(jLabel72, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 80, -1, -1));

        jSpinner7.setModel(new javax.swing.SpinnerNumberModel(0, 0, 50, 1));
        jPanel18.add(jSpinner7, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 100, 50, 20));

        jCheckBox7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox7ActionPerformed(evt);
            }
        });
        jPanel18.add(jCheckBox7, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 120, 50, 20));

        jPanel3.add(jPanel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 250, 160, 150));

        jPanel19.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230), 2));
        jPanel19.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel19.add(jLabel73, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 160, 50));

        jLabel75.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel75.setText("Price");
        jPanel19.add(jLabel75, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, -1, -1));

        jLabel76.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel76.setText("Quantity");
        jPanel19.add(jLabel76, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, -1, -1));

        jLabel77.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel77.setText("Purchase");
        jPanel19.add(jLabel77, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, -1, -1));

        jLabel78.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel78.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel78.setText("Cookies");
        jPanel19.add(jLabel78, new org.netbeans.lib.awtextra.AbsoluteConstraints(5, 60, 150, -1));

        jLabel79.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel79.setText("$65.0");
        jPanel19.add(jLabel79, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 80, -1, -1));

        jSpinner8.setModel(new javax.swing.SpinnerNumberModel(0, 0, 50, 1));
        jPanel19.add(jSpinner8, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 100, 50, 20));

        jCheckBox8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox8ActionPerformed(evt);
            }
        });
        jPanel19.add(jCheckBox8, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 120, 50, 20));

        jPanel3.add(jPanel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 250, 160, 150));

        jPanel20.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230), 2));
        jPanel20.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel20.add(jLabel80, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 160, 50));

        jLabel82.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel82.setText("Price");
        jPanel20.add(jLabel82, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, -1, -1));

        jLabel83.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel83.setText("Quantity");
        jPanel20.add(jLabel83, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, -1, -1));

        jLabel84.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel84.setText("Purchase");
        jPanel20.add(jLabel84, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, -1, -1));

        jLabel85.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel85.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel85.setText("Sandwiches");
        jPanel20.add(jLabel85, new org.netbeans.lib.awtextra.AbsoluteConstraints(8, 60, 130, -1));

        jLabel86.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel86.setText("$68.0");
        jPanel20.add(jLabel86, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 80, -1, -1));

        jSpinner9.setModel(new javax.swing.SpinnerNumberModel(0, 0, 50, 1));
        jPanel20.add(jSpinner9, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 100, 50, 20));

        jCheckBox9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox9ActionPerformed(evt);
            }
        });
        jPanel20.add(jCheckBox9, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 120, 50, 20));

        jPanel3.add(jPanel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 250, -1, 150));

        jLabel32.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel32.setText("MENU ITEMS");
        jPanel3.add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 30, -1, -1));

        btnTotal.setBackground(new java.awt.Color(255, 153, 204));
        btnTotal.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnTotal.setText("Total");
        btnTotal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTotalActionPerformed(evt);
            }
        });
        jPanel3.add(btnTotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 410, -1, -1));

        btnReceipt.setBackground(new java.awt.Color(0, 204, 204));
        btnReceipt.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnReceipt.setText("Receipt");
        btnReceipt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReceiptActionPerformed(evt);
            }
        });
        jPanel3.add(btnReceipt, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 410, -1, -1));

        btnReset.setBackground(new java.awt.Color(255, 255, 0));
        btnReset.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnReset.setText("Reset");
        btnReset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnResetActionPerformed(evt);
            }
        });
        jPanel3.add(btnReset, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 410, -1, -1));

        btnExit.setBackground(new java.awt.Color(255, 51, 51));
        btnExit.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnExit.setText("Exit");
        btnExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExitActionPerformed(evt);
            }
        });
        jPanel3.add(btnExit, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 410, -1, -1));

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 50, 830, 440));

        jPanel23.setBackground(new java.awt.Color(255, 204, 204));
        jPanel23.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTextArea.setColumns(20);
        jTextArea.setRows(5);
        jScrollPane2.setViewportView(jTextArea);

        jPanel23.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 330, 390));

        jTextFieldTotal.setEditable(false);
        jTextFieldTotal.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jTextFieldTotal.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextFieldTotal.setText("0.0");
        jPanel23.add(jTextFieldTotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(184, 460, 110, -1));

        jTextFieldTax.setEditable(false);
        jTextFieldTax.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jTextFieldTax.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextFieldTax.setText("0.0");
        jTextFieldTax.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldTaxActionPerformed(evt);
            }
        });
        jPanel23.add(jTextFieldTax, new org.netbeans.lib.awtextra.AbsoluteConstraints(184, 400, 110, -1));

        jTextFieldSubTotal.setEditable(false);
        jTextFieldSubTotal.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jTextFieldSubTotal.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextFieldSubTotal.setText("0.0");
        jTextFieldSubTotal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldSubTotalActionPerformed(evt);
            }
        });
        jPanel23.add(jTextFieldSubTotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(184, 430, 110, -1));

        jLabel87.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel87.setText("Total($)");
        jPanel23.add(jLabel87, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 460, 100, -1));

        jLabel88.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel88.setText("Tax($)");
        jPanel23.add(jLabel88, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 400, 100, -1));

        jPanel24.setBackground(new java.awt.Color(255, 204, 204));
        jPanel24.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTextArea3.setColumns(20);
        jTextArea3.setRows(5);
        jScrollPane3.setViewportView(jTextArea3);

        jPanel24.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 330, 390));
        jPanel24.add(jTextField5, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 460, -1, -1));

        jTextField6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField6ActionPerformed(evt);
            }
        });
        jPanel24.add(jTextField6, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 400, -1, -1));
        jPanel24.add(jTextField7, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 430, -1, -1));

        jLabel89.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel89.setText("Sub Total");
        jPanel24.add(jLabel89, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 420, -1, -1));

        jLabel90.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel90.setText("Tax");
        jPanel24.add(jLabel90, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 400, -1, -1));

        jPanel23.add(jPanel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 0, 330, 490));

        jLabel91.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel91.setText("Sub Total($)");
        jPanel23.add(jLabel91, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 430, -1, -1));

        getContentPane().add(jPanel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 0, 330, 490));
        getContentPane().add(jTxTime, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 0, 100, 50));

        jTxtDate.setFont(new java.awt.Font("Segoe UI", 0, 20)); // NOI18N
        getContentPane().add(jTxtDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 0, 100, 50));

        jLabel94.setText("jLabel94");
        getContentPane().add(jLabel94, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 920, 490));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jPasswordField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jPasswordField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jPasswordField1ActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jCheckBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton12ActionPerformed

    private void btnResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnResetActionPerformed
      
          reset(); // TODO add your handling code here:
    }//GEN-LAST:event_btnResetActionPerformed

    private void jTextFieldTaxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldTaxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldTaxActionPerformed

    private void jTextField6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField6ActionPerformed

    private void jTextFieldSubTotalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldSubTotalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldSubTotalActionPerformed
   public void MYCAFE(){
LocalDateTime now = LocalDateTime.now();
DateTimeFormatter timeFormat = DateTimeFormatter.ofPattern("HH:mm:ss");
DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("dd-MM-yyyy");

String time = now.format(timeFormat);
String date = now.format(dateFormat);

            jTextArea.setText(
    "***************** Welcome To Royal Cafe *****************\n"
  + "Time: " + time + "\n"
  + "Date: " + date + "\n"
  + "**************** Item Name & Price ****************\n"
);
}

    private void jCheckBox4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox4ActionPerformed

// Get quantity from spinner
 int qty = Integer.parseInt(jSpinner4.getValue().toString());

    if(qty > 0){
        // Quantity > 0, proceed with adding product
        if(jCheckBox4.isSelected()){
            x++;
            if(x == 1){
                MYCAFE();
            }
            double price = qty * 80.0;
            total += price;
            gettax((int) total);
            jTextArea.setText(jTextArea.getText() + x + ". " + jLabel51.getText() + "\t\t" + String.format("%.2f", price) + "\n");
            dudate();
        }
    } else {
        // Quantity = 0, prevent checkbox selection and show message
        jCheckBox4.setSelected(false);
        JOptionPane.showMessageDialog(null, "No product selected! Please select a quantity.");
    }
    }//GEN-LAST:event_jCheckBox4ActionPerformed

    private void jCheckBox5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox5ActionPerformed
      // Get quantity from spinner
int qty = Integer.parseInt(jSpinner5.getValue().toString());

    if(qty > 0 && jCheckBox5.isSelected()){
     
    x++;
if(x==1){
  MYCAFE();
}
 double price=qty*45.0;
 total +=price;
 gettax((int) total);
jTextArea.setText(jTextArea.getText()+x+". "+jLabel57.getText()+"\t\t"+price+"\n");
dudate();
}  else {
        jCheckBox5.setSelected(false);
        JOptionPane.showMessageDialog(null, "No product selected! Please select a quantity.");
    }// TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox5ActionPerformed

    private void jCheckBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox2ActionPerformed
    int qty = (Integer) jSpinner2.getValue();

    if (qty > 0 && jCheckBox2.isSelected()) {
        x++;
        if (x == 1) {
            MYCAFE();
        }

        double price = qty * 60.0;
        total +=price;
        gettax((int) total);
        jTextArea.setText(jTextArea.getText() + x + ". " + jLabel37.getText() + "\t\t" + price + "\n");
        dudate();
    } else {
        jCheckBox2.setSelected(false);
        JOptionPane.showMessageDialog(null, "No product selected! Please select a quantity.");
    }
  
// TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox2ActionPerformed

    private void jCheckBox3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox3ActionPerformed
       int qty = (Integer) jSpinner3.getValue();

    if (qty > 0 && jCheckBox3.isSelected()) {
        x++;
        if (x == 1) {
            MYCAFE();
        }

        double price = qty * 55.0;
        total +=price;
        gettax((int) total);
        jTextArea.setText(jTextArea.getText() + x + ". " + jLabel44.getText() + "\t\t" + price + "\n");
        dudate();
    } else {
        jCheckBox3.setSelected(false);
        JOptionPane.showMessageDialog(null, "No product selected! Please select a quantity.");
    }  // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox3ActionPerformed

    private void jCheckBox6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox6ActionPerformed
           int qty = (Integer) jSpinner6.getValue();

    if (qty > 0 && jCheckBox6.isSelected()) {
        x++;
        if (x == 1) {
            MYCAFE();
        }

        double price = qty * 50.0;
        total +=price;
        gettax((int) total);
        jTextArea.setText(jTextArea.getText() + x + ". " + jLabel64.getText() + "\t\t" + price + "\n");
        dudate();
    } else {
        jCheckBox6.setSelected(false);
        JOptionPane.showMessageDialog(null, "No product selected! Please select a quantity.");
    }  // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox6ActionPerformed

    private void jCheckBox7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox7ActionPerformed
           int qty = (Integer) jSpinner7.getValue();

    if (qty > 0 && jCheckBox7.isSelected()) {
        x++;
        if (x == 1) {
            MYCAFE();
        }

        double price = qty * 70.0;
        total +=price;
        gettax((int) total);
        jTextArea.setText(jTextArea.getText() + x + ". " + jLabel71.getText() + "\t\t" + price + "\n");
        dudate();
    } else {
        jCheckBox7.setSelected(false);
        JOptionPane.showMessageDialog(null, "No product selected! Please select a quantity.");
    }
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox7ActionPerformed

    private void jCheckBox8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox8ActionPerformed
           int qty = (Integer) jSpinner8.getValue();

    if (qty > 0 && jCheckBox8.isSelected()) {
        x++;
        if (x == 1) {
            MYCAFE();
        }

        double price = qty * 65.0;
        total +=price;
        gettax((int) total);
        jTextArea.setText(jTextArea.getText() + x + ". " + jLabel78.getText() + "\t\t" + price + "\n");
        dudate();
    } else {
        jCheckBox8.setSelected(false);
        JOptionPane.showMessageDialog(null, "No product selected! Please select a quantity.");
    }
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox8ActionPerformed

    private void jCheckBox9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox9ActionPerformed
         int qty = (Integer) jSpinner9.getValue();

    if (qty > 0 && jCheckBox9.isSelected()) {
        x++;
        if (x == 1) {
            MYCAFE();
        }
        double price = qty * 68.0;
        total +=price;
        gettax((int)total);
        jTextArea.setText(jTextArea.getText() + x + ". " + jLabel85.getText() + "\t\t" + price                                                                                                                                                                                                                                                                                                                                             + "\n");
        dudate();
    } else {
        jCheckBox9.setSelected(false);
        JOptionPane.showMessageDialog(null, "No product selected! Please select a quantity.");
    }

        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox9ActionPerformed

    private void btnTotalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTotalActionPerformed
   if(total==0.0){
    JOptionPane.showMessageDialog(null, "You havenot selected ant item!");
   }
   else{
    jTextArea.setText(jTextArea.getText()
           +"\n****************************************************\n"
    +"Tax: \t\t\t"+tax+"\n"
    +"Sub Total:\t\t\t"+total+"\n"
   +" Total:\t\t\t"+(total+tax)+"\n\n" 
    +"***************** ThankYou ******************\n");
    btnTotal.setEnabled(false);
   }      // TODO add your handling code here:
    }//GEN-LAST:event_btnTotalActionPerformed
 int xx, xy;
    private void formMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMouseDragged
    
  int x=evt.getXOnScreen();
  int y=evt.getYOnScreen();
  this.setLocation(x -xx, y-xy);
        // TODO add your handling code here:
    }//GEN-LAST:event_formMouseDragged

    private void formMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMousePressed
       xx=evt.getX();
       xy=evt.getY();
        // TODO add your handling code here:
    }//GEN-LAST:event_formMousePressed

    private void jLabel1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel1MousePressed

    private void btnReceiptActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReceiptActionPerformed
      if(total!=0 && !btnTotal.isEnabled()){
      try {
          jTextArea.print();
          // TODO add your handling code here:
      } catch (PrinterException ex) {
          Logger.getLogger(Loginpage.class.getName()).log(Level.SEVERE, null, ex);
      }
      }
      else{
      JOptionPane.showMessageDialog(null, "You have not purchase any product!");
      }  
    }//GEN-LAST:event_btnReceiptActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
      for(double i=0.0; i<=1.0; i +=0.1){
          try {
              String s= i+"";
              float f= Float.valueOf(s);
              this.setOpacity(f);
              Thread.sleep(40);
          }
          // TODO add your handling code here:
          catch (InterruptedException ex) {
              Logger.getLogger(Loginpage.class.getName()).log(Level.SEVERE, null, ex);
          }
      }
    }//GEN-LAST:event_formWindowOpened

    private void btnExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExitActionPerformed
    
    lastScreen lastScreenWindow = new lastScreen();
    lastScreenWindow.setVisible(true);    
    
    
    
    //System.exit(0);
    //dispose();
    
        // TODO add your handling code here:
    }//GEN-LAST:event_btnExitActionPerformed
 
    public void gettax(int t){
   if(t<100.0){
   tax=0.5;
   }
   else if(t>=100.0 && t<=200.0){
    tax=1.0;
   }
     else if(t>200.0 && t<=250.0){
    tax=2.0;
   }
    else if(t>250.0 && t<=300.0){
    tax=3.0;
   }
     else if(t>350.0 && t<=400.0){
    tax=4.0;
   }
    else if(t>450.0 && t<=500.0){
    tax=8.0;
   }
    else if(t>550.0 && t<=800.0){
    tax=10.0;
    }
    else if(t>800.0){
     tax=15.0;
    }
 }
    public void setTime(){
    new Thread(new Runnable(){
    @Override
    public void run(){
     while(true){
         try{
         Thread.sleep(1000);
         } catch (InterruptedException ex){
           Logger.getLogger(Loginpage.class.getName()).log(Level.SEVERE,null,ex);         
         }
     Date date = new Date();
     SimpleDateFormat tf=new SimpleDateFormat("h:mm:ss aa");
     SimpleDateFormat df= new SimpleDateFormat("EEEE,dd-MM-yyyy");
     String time= tf.format(date);
     jTxTime.setText(time.split(" ")[0]+" "+time.split(" ")[1]);
     
    }
    }
    }).start();
    }
    /**
     * @param args the command line arguments
     */
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Loginpage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Loginpage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Loginpage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Loginpage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Loginpage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnExit;
    private javax.swing.JButton btnReceipt;
    private javax.swing.JButton btnReset;
    private javax.swing.JButton btnTotal;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton18;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JCheckBox jCheckBox2;
    private javax.swing.JCheckBox jCheckBox3;
    private javax.swing.JCheckBox jCheckBox4;
    private javax.swing.JCheckBox jCheckBox5;
    private javax.swing.JCheckBox jCheckBox6;
    private javax.swing.JCheckBox jCheckBox7;
    private javax.swing.JCheckBox jCheckBox8;
    private javax.swing.JCheckBox jCheckBox9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JLabel jLabel69;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel70;
    private javax.swing.JLabel jLabel71;
    private javax.swing.JLabel jLabel72;
    private javax.swing.JLabel jLabel73;
    private javax.swing.JLabel jLabel74;
    private javax.swing.JLabel jLabel75;
    private javax.swing.JLabel jLabel76;
    private javax.swing.JLabel jLabel77;
    private javax.swing.JLabel jLabel78;
    private javax.swing.JLabel jLabel79;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel80;
    private javax.swing.JLabel jLabel81;
    private javax.swing.JLabel jLabel82;
    private javax.swing.JLabel jLabel83;
    private javax.swing.JLabel jLabel84;
    private javax.swing.JLabel jLabel85;
    private javax.swing.JLabel jLabel86;
    private javax.swing.JLabel jLabel87;
    private javax.swing.JLabel jLabel88;
    private javax.swing.JLabel jLabel89;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabel90;
    private javax.swing.JLabel jLabel91;
    private javax.swing.JLabel jLabel93;
    private javax.swing.JLabel jLabel94;
    private javax.swing.JLabel jLabelimage;
    private javax.swing.JLabel jLabelimage1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JSpinner jSpinner1;
    private javax.swing.JSpinner jSpinner10;
    private javax.swing.JSpinner jSpinner2;
    private javax.swing.JSpinner jSpinner3;
    private javax.swing.JSpinner jSpinner4;
    private javax.swing.JSpinner jSpinner5;
    private javax.swing.JSpinner jSpinner6;
    private javax.swing.JSpinner jSpinner7;
    private javax.swing.JSpinner jSpinner8;
    private javax.swing.JSpinner jSpinner9;
    private javax.swing.JTextArea jTextArea;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextArea jTextArea3;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextFieldSubTotal;
    private javax.swing.JTextField jTextFieldTax;
    private javax.swing.JTextField jTextFieldTotal;
    private javax.swing.JLabel jTxTime;
    private javax.swing.JLabel jTxtDate;
    private javax.swing.JLabel labelColdCoffee;
    // End of variables declaration//GEN-END:variables


}
