/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.abc;

/**
 *
 * @author UC 313
 */
public class Abc {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
